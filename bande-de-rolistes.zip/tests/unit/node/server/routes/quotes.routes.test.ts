import { beforeEach, describe, expect, it, vi } from "vitest";

import { makeReq, makeRes } from "@/../tests/helpers/express";
import { createRouterMock } from "./_routerMock";

const router = createRouterMock();

vi.mock("express", async () => {
  const actual = (await vi.importActual("express")) as Record<string, unknown>;
  return { ...actual, Router: () => router };
});

vi.mock("sequelize", () => ({
  Op: { or: "or", like: "like" },
}));

const Quote = {
  findAndCountAll: vi.fn(),
  create: vi.fn(),
  findByPk: vi.fn(),
  destroy: vi.fn(),
};

vi.mock("@/server/models", () => ({ Quote }));

const requireAuth = vi.fn();
const requireStaff = vi.fn();

vi.mock("@/server/middleware", () => ({
  requireAuth,
  requireStaff,
}));

const verifyCsrfMw = vi.fn();
const verifyCsrf = vi.fn(() => verifyCsrfMw);
vi.mock("@/server/middleware/csrf", () => ({ verifyCsrf }));

type ResWithSend = ReturnType<typeof makeRes> & { send?: unknown };

function ensureRes(res: ResWithSend) {
  const r = res as unknown as Record<string, unknown>;
  if (!r.status) r.status = vi.fn().mockReturnThis();
  if (!r.json) r.json = vi.fn().mockReturnThis();
  if (!r.send) r.send = vi.fn().mockReturnThis();
  return r;
}

async function load() {
  vi.resetModules();
  router.get.mockClear();
  router.post.mockClear();
  router.put.mockClear();
  router.delete.mockClear();

  await import("@/server/routes/quotes");

  const calls = {
    get: router.get.mock.calls,
    post: router.post.mock.calls,
    put: router.put.mock.calls,
    delete: router.delete.mock.calls,
  };

  const findHandler = (method: keyof typeof calls, path: string) => {
    const call = calls[method].find((c) => c[0] === path);
    if (!call) throw new Error(`Missing route ${method.toUpperCase()} ${path}`);
    return call[call.length - 1] as unknown as (
      req: unknown,
      res: unknown,
    ) => Promise<void>;
  };

  return {
    getQuotes: findHandler("get", "/quotes"),
    postQuotes: findHandler("post", "/quotes"),
    putQuote: findHandler("put", "/quotes/:quoteID"),
    deleteQuote: findHandler("delete", "/quotes/:quoteID"),
  };
}

describe("routes quotes", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("GET /quotes retourne la liste avec where à undefined, la pagination par défaut et le payload attendu", async () => {
    const { getQuotes } = await load();

    Quote.findAndCountAll.mockResolvedValue({
      rows: [{ quoteID: 1 }],
      count: 1,
    });

    const req = makeReq({ query: {} });
    const res = ensureRes(makeRes());

    await getQuotes(req, res);

    expect(Quote.findAndCountAll).toHaveBeenCalledTimes(1);
    const args = Quote.findAndCountAll.mock.calls[0]?.[0] as Record<
      string,
      unknown
    >;
    expect(args.where).toBeUndefined();
    expect(args.limit).toBe(10);
    expect(args.offset).toBe(0);

    expect((res.json as ReturnType<typeof vi.fn>).mock.calls[0]?.[0]).toEqual({
      items: [{ quoteID: 1 }],
      page: 1,
      limit: 10,
      totalItems: 1,
      totalPages: 1,
      q: "",
    });
  });

  it("GET /quotes borne page et limit, échappe q et définit where", async () => {
    const { getQuotes } = await load();

    Quote.findAndCountAll.mockResolvedValue({ rows: [], count: 120 });

    const req = makeReq({
      query: { page: "0", limit: "999", q: "  %_\\abc  " },
    });
    const res = ensureRes(makeRes());

    await getQuotes(req, res);

    const args = Quote.findAndCountAll.mock.calls[0]?.[0] as Record<
      string,
      unknown
    >;
    expect(args.limit).toBe(50);
    expect(args.offset).toBe(0);
    expect(args.where).toBeTruthy();

    const payload = (res.json as ReturnType<typeof vi.fn>).mock
      .calls[0]?.[0] as Record<string, unknown>;
    expect(payload.page).toBe(1);
    expect(payload.limit).toBe(50);
    expect(payload.totalPages).toBe(3);
    expect(payload.q).toBe("%_\\abc");
  });

  it("GET /quotes utilise les valeurs de repli pour page et limit si elles sont invalides", async () => {
    const { getQuotes } = await load();

    Quote.findAndCountAll.mockResolvedValue({ rows: [], count: 0 });

    const req = makeReq({
      query: { page: "NaN", limit: "0" },
    });
    const res = ensureRes(makeRes());

    await getQuotes(req, res);

    const args = Quote.findAndCountAll.mock.calls[0]?.[0] as Record<
      string,
      unknown
    >;
    expect(args.limit).toBe(10);
    expect(args.offset).toBe(0);
  });

  it("GET /quotes retourne 500 en cas d’erreur", async () => {
    const { getQuotes } = await load();

    Quote.findAndCountAll.mockRejectedValue(new Error("boom"));

    const req = makeReq({ query: {} });
    const res = ensureRes(makeRes());

    await getQuotes(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({
      code: "ERROR",
      message: "Erreur lors du chargement des citations",
    });
  });

  it("POST /quotes retourne 400 si le contenu est invalide", async () => {
    const { postQuotes } = await load();

    const req = makeReq({ body: { content: "  " } });
    const res = ensureRes(makeRes());

    await postQuotes(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({
      code: "BAD_REQUEST",
      message: "Contenu invalide",
    });
    expect(Quote.create).not.toHaveBeenCalled();
  });

  it("POST /quotes retourne 201 avec l’auteur par défaut", async () => {
    const { postQuotes } = await load();

    Quote.create.mockResolvedValue({ quoteID: 1 });

    const req = makeReq({ body: { content: "  hello  ", author: "  " } });
    const res = ensureRes(makeRes());

    await postQuotes(req, res);

    expect(Quote.create).toHaveBeenCalledWith({
      content: "hello",
      author: "Anonyme",
    });
    expect(res.status).toHaveBeenCalledWith(201);
    expect(res.json).toHaveBeenCalledWith({ quoteID: 1 });
  });

  it("POST /quotes retourne 201 avec l’auteur nettoyé", async () => {
    const { postQuotes } = await load();

    Quote.create.mockResolvedValue({ quoteID: 2 });

    const req = makeReq({ body: { content: "  abc  ", author: "  Bob  " } });
    const res = ensureRes(makeRes());

    await postQuotes(req, res);

    expect(Quote.create).toHaveBeenCalledWith({
      content: "abc",
      author: "Bob",
    });
    expect(res.status).toHaveBeenCalledWith(201);
  });

  it("POST /quotes retourne 500 en cas d’erreur", async () => {
    const { postQuotes } = await load();

    Quote.create.mockRejectedValue(new Error("boom"));

    const req = makeReq({ body: { content: "hello" } });
    const res = ensureRes(makeRes());

    await postQuotes(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({
      code: "ERROR",
      message: "Erreur lors de l'ajout de la citation",
    });
  });

  it("PUT /quotes/:quoteID retourne 400 si l’ID est invalide", async () => {
    const { putQuote } = await load();

    const req = makeReq({
      params: { quoteID: "NaN" },
      body: { content: "abc" },
    });
    const res = ensureRes(makeRes());

    await putQuote(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({
      code: "BAD_REQUEST",
      message: "ID invalide",
    });
  });

  it("PUT /quotes/:quoteID retourne 400 si le contenu est invalide", async () => {
    const { putQuote } = await load();

    const req = makeReq({ params: { quoteID: "1" }, body: { content: "a" } });
    const res = ensureRes(makeRes());

    await putQuote(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({
      code: "BAD_REQUEST",
      message: "Contenu invalide",
    });
  });

  it("PUT /quotes/:quoteID retourne 404 si la citation est introuvable", async () => {
    const { putQuote } = await load();

    Quote.findByPk.mockResolvedValue(null);

    const req = makeReq({ params: { quoteID: "1" }, body: { content: "abc" } });
    const res = ensureRes(makeRes());

    await putQuote(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith({
      code: "NOT_FOUND",
      message: "Citation introuvable",
    });
  });

  it("PUT /quotes/:quoteID met à jour puis retourne la citation avec l’auteur par défaut", async () => {
    const { putQuote } = await load();

    const quote = {
      content: "",
      author: "",
      save: vi.fn().mockResolvedValue(undefined),
    };
    Quote.findByPk.mockResolvedValue(quote);

    const req = makeReq({
      params: { quoteID: "2" },
      body: { content: "  abc  ", author: "  " },
    });
    const res = ensureRes(makeRes());

    await putQuote(req, res);

    expect(quote.content).toBe("abc");
    expect(quote.author).toBe("Anonyme");
    expect(quote.save).toHaveBeenCalledTimes(1);
    expect(res.json).toHaveBeenCalledWith(quote);
  });

  it("PUT /quotes/:quoteID met à jour puis retourne la citation avec l’auteur nettoyé", async () => {
    const { putQuote } = await load();

    const quote = {
      content: "",
      author: "",
      save: vi.fn().mockResolvedValue(undefined),
    };
    Quote.findByPk.mockResolvedValue(quote);

    const req = makeReq({
      params: { quoteID: "2" },
      body: { content: "  abc  ", author: "  Bob  " },
    });
    const res = ensureRes(makeRes());

    await putQuote(req, res);

    expect(quote.content).toBe("abc");
    expect(quote.author).toBe("Bob");
    expect(quote.save).toHaveBeenCalledTimes(1);
    expect(res.json).toHaveBeenCalledWith(quote);
  });

  it("PUT /quotes/:quoteID retourne 500 en cas d’erreur", async () => {
    const { putQuote } = await load();

    Quote.findByPk.mockRejectedValue(new Error("boom"));

    const req = makeReq({ params: { quoteID: "1" }, body: { content: "abc" } });
    const res = ensureRes(makeRes());

    await putQuote(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({
      code: "ERROR",
      message: "Erreur lors de la mise à jour",
    });
  });

  it("DELETE /quotes/:quoteID retourne 400 si l’ID est invalide", async () => {
    const { deleteQuote } = await load();

    const req = makeReq({ params: { quoteID: "NaN" } });
    const res = ensureRes(makeRes());

    await deleteQuote(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({
      code: "BAD_REQUEST",
      message: "ID invalide",
    });
  });

  it("DELETE /quotes/:quoteID retourne 404 si aucune citation n’est supprimée", async () => {
    const { deleteQuote } = await load();

    Quote.destroy.mockResolvedValue(0);

    const req = makeReq({ params: { quoteID: "1" } });
    const res = ensureRes(makeRes());

    await deleteQuote(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith({
      code: "NOT_FOUND",
      message: "Citation introuvable",
    });
  });

  it("DELETE /quotes/:quoteID retourne 204 si la citation est supprimée", async () => {
    const { deleteQuote } = await load();

    Quote.destroy.mockResolvedValue(1);

    const req = makeReq({ params: { quoteID: "1" } });
    const res = ensureRes(makeRes());

    await deleteQuote(req, res);

    expect(res.status).toHaveBeenCalledWith(204);
    expect(res.send).toHaveBeenCalledTimes(1);
  });

  it("DELETE /quotes/:quoteID retourne 500 en cas d’erreur", async () => {
    const { deleteQuote } = await load();

    Quote.destroy.mockRejectedValue(new Error("boom"));

    const req = makeReq({ params: { quoteID: "1" } });
    const res = ensureRes(makeRes());

    await deleteQuote(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({
      code: "ERROR",
      message: "Erreur lors de la suppression",
    });
  });
});
